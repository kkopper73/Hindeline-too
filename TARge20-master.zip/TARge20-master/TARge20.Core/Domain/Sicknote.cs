﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class Sicknote
    {
        public Guid Id { get; set; }
        public string reason { get; set; }
        public DateTime StartsAt { get; set; }
        public DateTime EndsAt { get; set; }
    }
}
