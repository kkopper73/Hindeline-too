﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TARge20.Core.Domain
{
    public class JobTitle
    {
        public Guid Id { get; set; }
        public string Job { get; set; }
        public string Department { get; set; }
    }
}
