﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TARge20.Core.Domain
{
    class Healt_insepction
    {
        [ForeignKey("Id")]

        public Guid Id { get; set; }
        
        public DateTime Date { get; set; }

    }
}
